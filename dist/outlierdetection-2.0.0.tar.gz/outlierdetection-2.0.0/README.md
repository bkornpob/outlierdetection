# outlierdetection
outlierdetection detects outliers given data and method.
