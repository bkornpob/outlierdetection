# outlierdetection
outlierdetection detects outliers given data and method.

pip install outlierdetection
